# neck_strap > color_v2
https://universe.roboflow.com/yeast-cells-object-detection/neck_strap

Provided by a Roboflow user
License: CC BY 4.0

