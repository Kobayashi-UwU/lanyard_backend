# neck_strap > Color
https://universe.roboflow.com/yeast-cells-object-detection/neck_strap

Provided by a Roboflow user
License: CC BY 4.0

